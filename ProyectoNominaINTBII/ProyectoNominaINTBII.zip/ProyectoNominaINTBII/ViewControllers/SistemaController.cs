﻿using Microsoft.AspNetCore.Mvc;

public class SistemaController : Controller
{
    public IActionResult Index()
    {
        return View();
    }
}
