using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SistemaNomina.Views.Admin
{
    public class Index1Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
